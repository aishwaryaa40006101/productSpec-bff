package com.pccw.prodspec.bff;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProdspecServiceBffApplicationTests {

	@Test
	void contextLoads() {
		ProdspecServiceBffApplication.main(new String[] {});
	}

}
